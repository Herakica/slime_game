import pygame
import random
import math
from dataclasses import dataclass

# =========================
# CONFIG
# =========================
WIDTH, HEIGHT = 960, 540
FPS = 60

PLAYER_SIZE = 32
PLAYER_MAX_HP = 20
PLAYER_INVULN_FRAMES = 35
CHUNK_SIZE = 256

DIFFS = {
    "easy": {
        "spawn_interval": 2.2,
        "max_npcs": 10,
        "max_items": 18,
        "snake_hp": 2,
        "owl_weight": 0.55,
        "hedge_weight": 0.45,
        "item_spawn_interval": 1.2,
        "snake_speed": 1.15,
        "score_to_spawn_snake": 60,
    },
    "hard": {
        "spawn_interval": 1.1,
        "max_npcs": 18,
        "max_items": 26,
        "snake_hp": 4,
        "owl_weight": 0.75,
        "hedge_weight": 0.25,
        "item_spawn_interval": 0.8,
        "snake_speed": 1.45,
        "score_to_spawn_snake": 80,
    },
}

# =========================
# HELPERS
# =========================
def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def draw_health_frame(surface, hp, max_hp, frame_img):
    """
    - Automatski 'cropa' health.png na dio koji nije transparentan (da ne dobiješ ogroman zeleni rect).
    - Crta HP fill unutar plavog okvira.
    - Stavlja health bar dolje na sredinu.
    """

    # 1) crop na vidljivi dio (ne-transparentan)
    br = frame_img.get_bounding_rect()  # Rect oko pixela koji nisu prozirni
    frame = frame_img.subsurface(br)   # samo taj dio
    w, h = frame.get_width(), frame.get_height()

    # 2) pozicija: DOLJE SREDINA
    x = WIDTH // 2 - w // 2
    y = HEIGHT - h - 6  # spusti još niže (povećaj/smanji po ukusu)

    # 3) "unutarnja traka" (padding) - OVO je dio koji podešavaš da bude unutar plavog
    #    Kreni od ovih vrijednosti i sitno popravi dok ne sjedne savršeno.
    pad_left = 12
    pad_right = 18
    pad_top = 20
    pad_bottom = 12

    inner_x = x + pad_left
    inner_y = y + pad_top
    inner_w = w - pad_left - pad_right
    inner_h = h - pad_top - pad_bottom

    # 4) koliko je hp
    ratio = 0 if max_hp <= 0 else max(0, min(1, hp / max_hp))
    fill_w = int(inner_w * ratio)

    # 5) fill iza okvira (prazno + hp)
    pygame.draw.rect(surface, (20, 20, 20), (inner_x, inner_y, inner_w, inner_h))
    pygame.draw.rect(surface, (60, 220, 90), (inner_x, inner_y, fill_w, inner_h))

    # 6) okvir na vrh
    surface.blit(frame, (x, y))

def try_random_spawn_near(player_x, player_y, min_dist, max_dx, max_dy, attempts=25):
    for _ in range(attempts):
        x = player_x + random.randint(-max_dx, max_dx)
        y = player_y + random.randint(-max_dy, max_dy)
        if abs(x - player_x) < min_dist and abs(y - player_y) < min_dist:
            continue
        return x, y
    return None

def draw_tiled_background(surface, cam_x, cam_y, bg_img):
    bw, bh = bg_img.get_width(), bg_img.get_height()
    start_x = -int(cam_x % bw)
    start_y = -int(cam_y % bh)

    y = start_y
    while y < HEIGHT:
        x = start_x
        while x < WIDTH:
            surface.blit(bg_img, (x, y))
            x += bw
        y += bh

def load_strip_frames(path, frame_w, frame_h, scale=1):
    sheet = pygame.image.load(path).convert_alpha()
    sw, sh = sheet.get_size()
    count = sw // frame_w

    frames = []
    for i in range(count):
        frame = pygame.Surface((frame_w, frame_h), pygame.SRCALPHA)
        frame.blit(sheet, (0, 0), pygame.Rect(i * frame_w, 0, frame_w, frame_h))
        if scale != 1:
            frame = pygame.transform.scale(frame, (frame_w * scale, frame_h * scale))
        frames.append(frame)
    return frames

# =========================
# UI BUTTON
# =========================
class Button:
    def __init__(self, rect, text):
        self.rect = pygame.Rect(rect)
        self.text = text

    def draw(self, surface, font, mouse_pos):
        hover = self.rect.collidepoint(mouse_pos)
        bg = (70, 70, 90) if not hover else (95, 95, 130)
        pygame.draw.rect(surface, bg, self.rect, border_radius=10)
        pygame.draw.rect(surface, (220, 220, 230), self.rect, 2, border_radius=10)

        label = font.render(self.text, True, (255, 255, 255))
        surface.blit(
            label,
            (self.rect.centerx - label.get_width() // 2, self.rect.centery - label.get_height() // 2),
        )

    def clicked(self, event):
        return event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.rect.collidepoint(event.pos)

# =========================
# POWER-UPS
# =========================
class PowerUp:
    duration = 0.0  # seconds; 0 = instant
    def apply(self, player): ...
    def remove(self, player): ...

class SpeedBoost(PowerUp):
    def __init__(self, mult=1.35, duration=5.0):
        self.mult = mult
        self.duration = duration
    def apply(self, player):
        player.speed *= self.mult
    def remove(self, player):
        player.speed /= self.mult

class ShieldCharge(PowerUp):
    def __init__(self, charges=1):
        self.charges = charges
        self.duration = 0.0
    def apply(self, player):
        player.shield += self.charges

class Heal(PowerUp):
    def __init__(self, amount=3):
        self.amount = amount
        self.duration = 0.0
    def apply(self, player):
        player.hp = min(PLAYER_MAX_HP, player.hp + self.amount)

# =========================
# ENTITIES
# =========================
class Entity:
    size = 32
    edible = False
    def __init__(self, x, y):
        self.x, self.y = float(x), float(y)
        self.alive = True

    @property
    def rect(self):
        s = self.size
        return pygame.Rect(int(self.x - s / 2), int(self.y - s / 2), s, s)

    def update(self, dt, world): ...
    def draw(self, surface, cam_x, cam_y, world): ...
    def on_eaten(self, player): return None

class Player(Entity):
    size = PLAYER_SIZE

    def __init__(self, x, y):
        super().__init__(x, y)
        self.hp = PLAYER_MAX_HP
        self.invuln = 0
        self.speed = 2.6
        self.effects = []
        self.shield = 0
        self.score = 0

        # attack anim
        self.attacking = False
        self.attack_elapsed = 0.0
        self.facing = "right"

    def apply_powerup(self, pu: PowerUp):
        pu.apply(self)
        if getattr(pu, "duration", 0) and pu.duration > 0:
            self.effects.append(pu)

    def take_damage(self, amount):
        # (Enemies no longer hurt you on touch. Only traps can call this.)
        if self.invuln > 0:
            return
        if self.shield > 0:
            self.shield -= 1
            self.invuln = PLAYER_INVULN_FRAMES // 2
            return
        self.hp -= amount
        self.invuln = PLAYER_INVULN_FRAMES

    def get_attack_hitbox(self, world):
        """Rect in front of player used for attack collisions."""
        # Range tuned for SCALE=2 and 32x32 frames.
        range_px = 26 * world.scale
        width = 34 * world.scale
        height = 26 * world.scale

        if self.facing == "right":
            x = self.x + range_px
        else:
            x = self.x - range_px
        y = self.y

        return pygame.Rect(int(x - width / 2), int(y - height / 2), int(width), int(height))

    def update(self, dt, world):
        keys = pygame.key.get_pressed()
        dx = (keys[pygame.K_d] - keys[pygame.K_a])
        dy = (keys[pygame.K_s] - keys[pygame.K_w])

        if dx < 0:
            self.facing = "left"
        elif dx > 0:
            self.facing = "right"

        # start attack
        if keys[pygame.K_SPACE] and not self.attacking:
            self.attacking = True
            self.attack_elapsed = 0.0

        # tick attack
        if self.attacking:
            self.attack_elapsed += dt
            frames = world.assets["attack_left"] if self.facing == "left" else world.assets["attack_right"]
            frame_time = world.assets["attack_frame_time"]
            total_time = len(frames) * frame_time
            if self.attack_elapsed >= total_time:
                self.attacking = False

        # normalize movement
        if dx != 0 or dy != 0:
            l = math.hypot(dx, dy)
            dx /= l
            dy /= l

        self.x += dx * self.speed * 60 * dt
        self.y += dy * self.speed * 60 * dt

        if self.invuln > 0:
            self.invuln -= 1

        # tick timed powerups
        new_effects = []
        for eff in self.effects:
            eff.duration -= dt
            if eff.duration <= 0:
                eff.remove(self)
            else:
                new_effects.append(eff)
        self.effects = new_effects

    def draw(self, surface, cam_x, cam_y, world):
        if self.attacking:
            frames = world.assets["attack_left"] if self.facing == "left" else world.assets["attack_right"]
            frame_time = world.assets["attack_frame_time"]
            idx = int(self.attack_elapsed / frame_time)
            idx = min(idx, len(frames) - 1)
            img = frames[idx]
        else:
            img = world.assets["slime_idle"]

        surface.blit(img, (int(self.x - cam_x - img.get_width() // 2),
                           int(self.y - cam_y - img.get_height() // 2)))

        if self.shield > 0:
            pygame.draw.circle(surface, (255, 255, 255),
                               (int(self.x - cam_x), int(self.y - cam_y)),
                               self.size // 2 + 8, 2)

        # Debug attack hitbox (toggle if needed)
        # if self.attacking:
        #     hb = self.get_attack_hitbox(world).move(-cam_x, -cam_y)
        #     pygame.draw.rect(surface, (255, 0, 0), hb, 2)

class Owl(Entity):
    size = 30
    edible = True  # you can "eat" it when attacking

    def __init__(self, x, y):
        super().__init__(x, y)
        self.vx, self.vy = 0.0, 0.0
        self.t = random.random() * 10

    def update(self, dt, world):
        player = world.player
        self.t += 2.6 * dt

        # wander + avoid player (doesn't damage on touch)
        dx = self.x - player.x
        dy = self.y - player.y
        d = math.hypot(dx, dy) + 1e-6

        if d < 150:
            self.vx += (dx / d) * 0.8 * dt * 60
            self.vy += (dy / d) * 0.8 * dt * 60

        self.vx += math.cos(self.t) * 0.12
        self.vy += math.sin(self.t) * 0.12

        sp = 1.5
        self.vx = clamp(self.vx, -sp, sp)
        self.vy = clamp(self.vy, -sp, sp)

        self.x += self.vx * 60 * dt
        self.y += self.vy * 60 * dt

    def draw(self, surface, cam_x, cam_y, world):
        img = world.assets["owl_img"]
        surface.blit(img, (int(self.x - cam_x - img.get_width() // 2),
                           int(self.y - cam_y - img.get_height() // 2)))

    def on_eaten(self, player):
        return SpeedBoost(mult=1.35, duration=5.0)

class Hedgehog(Entity):
    size = 28
    edible = True

    def draw(self, surface, cam_x, cam_y, world):
        img = world.assets["hedgehog_img"]
        surface.blit(img, (int(self.x - cam_x - img.get_width() // 2),
                           int(self.y - cam_y - img.get_height() // 2)))

    def on_eaten(self, player):
        return ShieldCharge(charges=1)

class Snake(Entity):
    size = 44
    edible = True

    def __init__(self, x, y, hp=3):
        super().__init__(x, y)
        self.hp = hp
        self.vx, self.vy = 0.0, 0.0
        self.facing = "right"  # "left" / "right"

    def update(self, dt, world):
        player = world.player
        dx = player.x - self.x
        dy = player.y - self.y
        d = math.hypot(dx, dy) + 1e-6

        sp = world.diff["snake_speed"]
        self.vx = (dx / d) * sp
        self.vy = (dy / d) * sp

        # odredi smjer (koristi vx)
        if self.vx < -0.01:
            self.facing = "left"
        elif self.vx > 0.01:
            self.facing = "right"

        self.x += self.vx * 60 * dt
        self.y += self.vy * 60 * dt

    def draw(self, surface, cam_x, cam_y, world):
        img = world.assets["snake_left"] if self.facing == "left" else world.assets["snake_right"]

        surface.blit(
            img,
            (int(self.x - cam_x - img.get_width() // 2),
             int(self.y - cam_y - img.get_height() // 2))
        )

        # HP iznad zmije
        txt = world.ui_font_small.render(f"Snake HP: {self.hp}", True, (255, 255, 255))
        surface.blit(txt, (int(self.x - cam_x - 40), int(self.y - cam_y - img.get_height() // 2 - 18)))

class Item(Entity):
    edible = True
    def __init__(self, x, y, sprite_key, powerup_factory):
        super().__init__(x, y)
        self.sprite_key = sprite_key
        self.powerup_factory = powerup_factory
        self.size = 26

    def draw(self, surface, cam_x, cam_y, world):
        img = world.assets[self.sprite_key]
        surface.blit(img, (int(self.x - cam_x - img.get_width() // 2),
                           int(self.y - cam_y - img.get_height() // 2)))

    def on_eaten(self, player):
        return self.powerup_factory()

class Trap(Entity):
    edible = False
    def __init__(self, x, y, radius=18, damage=2):
        super().__init__(x, y)
        self.radius = radius
        self.damage = damage

    @property
    def rect(self):
        r = self.radius
        return pygame.Rect(int(self.x - r), int(self.y - r), r * 2, r * 2)

    def update(self, dt, world):
        if self.rect.colliderect(world.player.rect):
            world.player.take_damage(self.damage)

    def draw(self, surface, cam_x, cam_y, world):
        pygame.draw.circle(surface, (220, 60, 60),
                           (int(self.x - cam_x), int(self.y - cam_y)),
                           self.radius, 3)

# =========================
# WORLD
# =========================
@dataclass
class World:
    player: Player
    entities: list
    traps: list
    seen_chunks: set
    spawn_timer: float
    item_timer: float
    snake_spawned: bool
    assets: dict
    ui_font: any
    ui_font_small: any
    diff: dict
    scale: int

# =========================
# SPAWNERS
# =========================
def spawn_random_npc(world: World):
    p = world.player
    pos = try_random_spawn_near(p.x, p.y, min_dist=140, max_dx=450, max_dy=350)
    if not pos:
        return
    x, y = pos
    if random.random() < world.diff["owl_weight"]:
        world.entities.append(Owl(x, y))
    else:
        world.entities.append(Hedgehog(x, y))

def spawn_random_item(world: World):
    p = world.player
    pos = try_random_spawn_near(p.x, p.y, min_dist=90, max_dx=420, max_dy=320)
    if not pos:
        return
    x, y = pos
    if random.random() < 0.55:
        world.entities.append(Item(x, y, "item_grass", lambda: Heal(amount=3)))
    else:
        world.entities.append(Item(x, y, "item_bush", lambda: ShieldCharge(charges=1)))

def spawn_chunk_pack(world: World, cx, cy):
    n_npc = random.randint(2, 5) if world.diff is DIFFS["easy"] else random.randint(3, 6)
    n_item = random.randint(2, 4) if world.diff is DIFFS["easy"] else random.randint(3, 6)

    for _ in range(n_npc):
        x = cx * CHUNK_SIZE + random.randint(32, CHUNK_SIZE - 32)
        y = cy * CHUNK_SIZE + random.randint(32, CHUNK_SIZE - 32)
        world.entities.append(Owl(x, y) if random.random() < 0.5 else Hedgehog(x, y))

    for _ in range(n_item):
        x = cx * CHUNK_SIZE + random.randint(32, CHUNK_SIZE - 32)
        y = cy * CHUNK_SIZE + random.randint(32, CHUNK_SIZE - 32)
        if random.random() < 0.55:
            world.entities.append(Item(x, y, "item_grass", lambda: Heal(amount=3)))
        else:
            world.entities.append(Item(x, y, "item_bush", lambda: ShieldCharge(charges=1)))

def maybe_spawn_snake(world: World):
    if world.snake_spawned:
        return
    if world.player.score >= world.diff["score_to_spawn_snake"]:
        p = world.player
        x = p.x + random.choice([-1, 1]) * random.randint(380, 520)
        y = p.y + random.choice([-1, 1]) * random.randint(280, 420)
        world.entities.append(Snake(x, y, hp=world.diff["snake_hp"]))
        world.snake_spawned = True

# =========================
# GAME FACTORY
# =========================
def make_world(assets, ui_font, ui_font_small, difficulty_name, scale):
    player = Player(0, 0)
    world = World(
        player=player,
        entities=[],
        traps=[],
        seen_chunks=set(),
        spawn_timer=0.0,
        item_timer=0.0,
        snake_spawned=False,
        assets=assets,
        ui_font=ui_font,
        ui_font_small=ui_font_small,
        diff=DIFFS[difficulty_name],
        scale=scale,
    )
    cx = int(player.x) // CHUNK_SIZE
    cy = int(player.y) // CHUNK_SIZE
    world.seen_chunks.add((cx, cy))
    spawn_chunk_pack(world, cx, cy)
    return world

# =========================
# MAIN
# =========================
def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Slime - Menu + Difficulty + Attack-only damage")
    clock = pygame.time.Clock()

    ui_font = pygame.font.SysFont("consolas", 28)
    ui_font_small = pygame.font.SysFont("consolas", 16)
    ui_font_med = pygame.font.SysFont("consolas", 20)

    SCALE = 2

    def load_img(path, scale=1):
        img = pygame.image.load(path).convert_alpha()
        if scale != 1:
            w, h = img.get_size()
            img = pygame.transform.scale(img, (int(w * scale), int(h * scale)))
        return img

    # Attack sheet: your files look like 960x32 => 30 frames of 32x32
    attack_left_frames = load_strip_frames("grizljevo.png", 32, 32, scale=SCALE)
    attack_right_frames = load_strip_frames("grizdesno.png", 32, 32, scale=SCALE)

    assets = {
        "bg": load_img("grassland.png", 1),
        "slime_idle": load_img("slime4.png", SCALE),

        "attack_left": attack_left_frames,
        "attack_right": attack_right_frames,
        "attack_frame_time": 0.03,
        "health_frame": load_img("health.png", 3),
        "owl_img": load_img("sova.png", SCALE),
        "hedgehog_img": load_img("jez.png", SCALE),
        "snake_right": load_img("zmijadesno.png", SCALE),
        "snake_left":  load_img("zmijaljevo.png", SCALE),
        "item_grass": load_img("grass.png", SCALE),
        "item_bush": load_img("bush.png", SCALE),
    }

    # UI states
    state = "menu"  # "menu" -> "difficulty" -> "game"
    play_btn = Button((WIDTH//2 - 120, HEIGHT//2 - 40, 240, 60), "PLAY")
    easy_btn = Button((WIDTH//2 - 120, HEIGHT//2 - 70, 240, 60), "EASY")
    hard_btn = Button((WIDTH//2 - 120, HEIGHT//2 + 10, 240, 60), "HARD")
    back_btn = Button((20, 20, 140, 50), "BACK")

    world = None
    difficulty = "easy"

    running = True
    while running:
        dt = clock.tick(FPS) / 1000.0
        mouse = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if state == "menu":
                if play_btn.clicked(event):
                    state = "difficulty"

            elif state == "difficulty":
                if back_btn.clicked(event):
                    state = "menu"
                elif easy_btn.clicked(event):
                    difficulty = "easy"
                    world = make_world(assets, ui_font_med, ui_font_small, difficulty, SCALE)
                    state = "game"
                elif hard_btn.clicked(event):
                    difficulty = "hard"
                    world = make_world(assets, ui_font_med, ui_font_small, difficulty, SCALE)
                    state = "game"

            elif state == "game":
                # ESC back to menu
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    state = "menu"
                    world = None

        # =========================
        # DRAW/UPDATE PER STATE
        # =========================
        if state == "menu":
            screen.fill((18, 18, 26))
            title = ui_font.render("SLIME GAME", True, (255, 255, 255))
            screen.blit(title, (WIDTH//2 - title.get_width()//2, 120))
            subtitle = ui_font_med.render("Click PLAY to choose difficulty", True, (200, 200, 220))
            screen.blit(subtitle, (WIDTH//2 - subtitle.get_width()//2, 170))

            play_btn.draw(screen, ui_font_med, mouse)
            pygame.display.flip()
            continue

        if state == "difficulty":
            screen.fill((18, 18, 26))
            title = ui_font.render("CHOOSE DIFFICULTY", True, (255, 255, 255))
            screen.blit(title, (WIDTH//2 - title.get_width()//2, 120))

            easy_btn.draw(screen, ui_font_med, mouse)
            hard_btn.draw(screen, ui_font_med, mouse)
            back_btn.draw(screen, ui_font_med, mouse)

            pygame.display.flip()
            continue

        # =========================
        # GAME STATE
        # =========================
        assert world is not None

        # UPDATE world
        world.player.update(dt, world)

        # timed spawns
        world.spawn_timer += dt
        alive_npcs = [e for e in world.entities if e.alive and isinstance(e, (Owl, Hedgehog))]
        if world.spawn_timer >= world.diff["spawn_interval"] and len(alive_npcs) < world.diff["max_npcs"]:
            world.spawn_timer = 0.0
            spawn_random_npc(world)

        world.item_timer += dt
        alive_items = [e for e in world.entities if e.alive and isinstance(e, Item)]
        if world.item_timer >= world.diff["item_spawn_interval"] and len(alive_items) < world.diff["max_items"]:
            world.item_timer = 0.0
            spawn_random_item(world)

        # chunk spawn
        cx = int(world.player.x) // CHUNK_SIZE
        cy = int(world.player.y) // CHUNK_SIZE
        if (cx, cy) not in world.seen_chunks:
            world.seen_chunks.add((cx, cy))
            spawn_chunk_pack(world, cx, cy)

        maybe_spawn_snake(world)

        # update entities + traps
        for e in world.entities:
            if e.alive:
                e.update(dt, world)
        for t in world.traps:
            if t.alive:
                t.update(dt, world)

        # =========================
        # COLLISIONS
        # =========================
        pr = world.player.rect

        # Items: eat on touch (if you want attack-only for items too, tell me)
        for e in world.entities:
            if not e.alive:
                continue
            if isinstance(e, Item) and pr.colliderect(e.rect):
                pu = e.on_eaten(world.player)
                if pu:
                    world.player.apply_powerup(pu)
                e.alive = False
                world.player.score += 5

        # Enemies/Snake: ONLY when attacking (hitbox)
        if world.player.attacking:
            hitbox = world.player.get_attack_hitbox(world)
            for e in world.entities:
                if not e.alive:
                    continue
                if isinstance(e, (Owl, Hedgehog, Snake)) and hitbox.colliderect(e.rect):
                    if isinstance(e, Snake):
                        e.hp -= 1
                        if e.hp <= 0:
                            e.alive = False
                            print("YOU WIN! Pojeo si zmiju.")
                            state = "menu"
                            world = None
                            break
                        else:
                            world.player.score += 3
                    else:
                        pu = e.on_eaten(world.player)
                        if pu:
                            world.player.apply_powerup(pu)
                        e.alive = False
                        world.player.score += 10

        # cleanup
        world.entities = [e for e in world.entities if e.alive or isinstance(e, Snake)]

        # game over (only traps can reduce hp)
        if world.player.hp <= 0:
            print("GAME OVER")
            state = "menu"
            world = None
            continue

        # CAMERA
        cam_x = world.player.x - WIDTH // 2
        cam_y = world.player.y - HEIGHT // 2

        # DRAW
        draw_tiled_background(screen, cam_x, cam_y, world.assets["bg"])

        for t in world.traps:
            if t.alive:
                t.draw(screen, cam_x, cam_y, world)

        for e in world.entities:
            if e.alive:
                e.draw(screen, cam_x, cam_y, world)

        world.player.draw(screen, cam_x, cam_y, world)

        # UI
        draw_health_frame(screen, world.player.hp, PLAYER_MAX_HP, world.assets["health_frame"])
        ui1 = ui_font_small.render(f"Score: {world.player.score}", True, (255, 255, 0))
        ui2 = ui_font_small.render(f"Shield: {world.player.shield}", True, (255, 255, 255))
        ui3 = ui_font_small.render(f"Difficulty: {difficulty.upper()}  (SPACE=attack, ESC=menu)", True, (255, 255, 255))
        ui4 = ui_font_small.render(f"Snake spawns at score {world.diff['score_to_spawn_snake']}", True, (255, 255, 255))
        screen.blit(ui1, (10, 32))
        screen.blit(ui2, (10, 52))
        screen.blit(ui3, (10, 72))
        screen.blit(ui4, (10, 92))

        pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()