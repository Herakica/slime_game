import pygame
import random

pygame.init()

# ================== SETTINGS ==================
WIDTH, HEIGHT = 512, 512
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Slime + chunks + destroy tiles")

clock = pygame.time.Clock()

CELL_W = 32
CELL_H = 32

TILES_X = WIDTH // CELL_W
TILES_Y = HEIGHT // CELL_H

BLOCK_TOKENS = 10

# tile HP
TILE_HP = {
    "grass": 1,
    "bush": 5,
}


# ================== HELPERS ==================

def load_grid(sheet, frame_w, frame_h, max_frames=None):
    sw, sh = sheet.get_size()
    cols = sw // frame_w
    rows = sh // frame_h

    frames = []
    for row in range(rows):
        for col in range(cols):
            if max_frames is not None and len(frames) >= max_frames:
                return frames
            rect = pygame.Rect(col * frame_w, row * frame_h, frame_w, frame_h)
            frames.append(sheet.subsurface(rect).copy())
    return frames


# ================== BLOCK SISTEM ==================

class Block:
    def __init__(self, x, y, tiles_x, tiles_y, cell_w, cell_h,
                 token_budget, grass_img, bush_img):
        self.x = x
        self.y = y
        self.tiles_x = tiles_x
        self.tiles_y = tiles_y
        self.cell_w = cell_w
        self.cell_h = cell_h

        self.grass_img = grass_img
        self.bush_img = bush_img

        # što je na tileu
        self.grid = [["empty" for _ in range(tiles_x)] for _ in range(tiles_y)]
        # koliko HP ima tile (0 = nema ništa)
        self.hp_grid = [[0 for _ in range(tiles_x)] for _ in range(tiles_y)]

        self.token_budget = token_budget
        self.generate_contents()

    def place_item(self, tx, ty, item_name):
        self.grid[ty][tx] = item_name
        self.hp_grid[ty][tx] = TILE_HP.get(item_name, 0)

    def generate_contents(self):
        """
        Skroz random:
        - imamo token_budget poteza
        - svaki potez stavi grass ili bush na random tile
        """
        for _ in range(self.token_budget):
            tx = random.randint(0, self.tiles_x - 1)
            ty = random.randint(0, self.tiles_y - 1)

            item = "bush" if random.random() < 0.25 else "grass"
            self.place_item(tx, ty, item)

    def damage_tile(self, tx, ty, dmg):
        """
        Skini HP tileu na (tx,ty).
        Ako HP padne na 0 -> nestane (postane empty).
        """
        if tx < 0 or tx >= self.tiles_x or ty < 0 or ty >= self.tiles_y:
            return

        if self.grid[ty][tx] == "empty":
            return

        self.hp_grid[ty][tx] -= dmg
        if self.hp_grid[ty][tx] <= 0:
            self.grid[ty][tx] = "empty"
            self.hp_grid[ty][tx] = 0

    def draw(self, surface, cam_x, cam_y):
        for ty in range(self.tiles_y):
            for tx in range(self.tiles_x):
                item = self.grid[ty][tx]
                if item == "empty":
                    continue

                world_x = self.x + tx * self.cell_w
                world_y = self.y + ty * self.cell_h

                screen_x = world_x - cam_x
                screen_y = world_y - cam_y

                if item == "grass":
                    surface.blit(self.grass_img, (screen_x, screen_y))
                elif item == "bush":
                    surface.blit(self.bush_img, (screen_x, screen_y))


# ================== LOAD IMAGES ==================

try:
    bg = pygame.image.load("grassland.png").convert()
except pygame.error:
    bg = None

slime_sheet = pygame.image.load("slime4.png").convert_alpha()
slime_frames = load_grid(slime_sheet, CELL_W, CELL_H, max_frames=2)
slime_idle_frame = slime_frames[0]

griz_left_sheet = pygame.image.load("grizlijevo.png").convert_alpha()
griz_left_frames = load_grid(griz_left_sheet, CELL_W, CELL_H, max_frames=30)

griz_right_sheet = pygame.image.load("grizdesno.png").convert_alpha()
griz_right_frames = load_grid(griz_right_sheet, CELL_W, CELL_H, max_frames=30)

grass_img = pygame.image.load("grass.png").convert_alpha()
bush_img = pygame.image.load("bush.png").convert_alpha()


# ================== CHUNKS ==================

chunks = {}

def get_or_create_chunk(cx: int, cy: int) -> Block:
    key = (cx, cy)
    if key in chunks:
        return chunks[key]

    block = Block(
        x=cx * WIDTH,
        y=cy * HEIGHT,
        tiles_x=TILES_X,
        tiles_y=TILES_Y,
        cell_w=CELL_W,
        cell_h=CELL_H,
        token_budget=BLOCK_TOKENS,
        grass_img=grass_img,
        bush_img=bush_img,
    )
    chunks[key] = block
    return block

get_or_create_chunk(0, 0)


# ================== PLAYER STATE ==================

px, py = WIDTH // 2, HEIGHT // 2
speed = 2

attacking = False
attack_frames = griz_right_frames
attack_index = 0
attack_timer = 0.0
attack_speed = 0.50  # veće = brže

facing = "right"
attack_hit_done = False

ATTACK_DAMAGE = 1  # koliko skida po udarcu (1 je ok jer grass=1, bush=5)

# u kojim frameovima se napad računa kao udarac
HIT_START = 10
HIT_END = 18

# koliko pomaknuti ugriz vizualno
BITE_OFFSET_X = 10


def get_front_tile(screen_px, screen_py):
    """
    Vrati tile (tx,ty) ispred igrača u trenutnom chunku.
    screen_px/screen_py su pozicija igrača na ekranu (centar).
    """
    # uzmi točku malo ispred lika
    if facing == "left":
        fx = screen_px - 20
    else:
        fx = screen_px + 20

    fy = screen_py

    tx = int(fx // CELL_W)
    ty = int(fy // CELL_H)
    return tx, ty


# ================== MAIN LOOP ==================

running = True
while running:
    # ----- events -----
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # click -> start attack
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if not attacking:
                attacking = True
                attack_timer = 0
                attack_index = 0
                attack_hit_done = False
                attack_frames = griz_left_frames if facing == "left" else griz_right_frames

    keys = pygame.key.get_pressed()

    # ----- update -----
    if attacking:
        attack_timer += attack_speed
        if attack_timer >= 1:
            attack_timer = 0
            attack_index += 1
            if attack_index >= len(attack_frames):
                attacking = False
                attack_index = 0
    else:
        dx = dy = 0
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            dx += speed
            facing = "right"
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            dx -= speed
            facing = "left"
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            dy -= speed
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            dy += speed

        px += dx
        py += dy

    # ----- chunk + camera -----
    cx = px // WIDTH
    cy = py // HEIGHT

    current_chunk = get_or_create_chunk(cx, cy)

    cam_x = cx * WIDTH
    cam_y = cy * HEIGHT

    screen_px = px - cam_x
    screen_py = py - cam_y

    # ----- apply damage to tile (once per attack) -----
    if attacking and (HIT_START <= attack_index <= HIT_END) and (not attack_hit_done):
        tx, ty = get_front_tile(screen_px, screen_py)

        # udari tile ispred sebe
        current_chunk.damage_tile(tx, ty, ATTACK_DAMAGE)

        # samo jednom po napadu (da ne udara 10 puta)
        attack_hit_done = True

    # ----- draw -----
    if bg is not None:
        win.blit(bg, (0, 0))
    else:
        win.fill((30, 120, 30))

    current_chunk.draw(win, cam_x, cam_y)

    # draw player
    sfw, sfh = slime_idle_frame.get_size()
    slime_draw_x = int(screen_px - sfw // 2)
    slime_draw_y = int(screen_py - sfh // 2)
    win.blit(slime_idle_frame, (slime_draw_x, slime_draw_y))

    # draw attack animation (visual)
    if attacking:
        bite_frame = attack_frames[attack_index]
        bfw, bfh = bite_frame.get_size()

        bite_draw_x = int(screen_px - bfw // 2)
        bite_draw_y = int(screen_py - bfh // 2)

        bite_draw_x += (-BITE_OFFSET_X if facing == "left" else BITE_OFFSET_X)

        win.blit(bite_frame, (bite_draw_x, bite_draw_y))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
